int main()
{
/* 1: this is * just a / sample */
int n;
int abc, def, main_1;
int a1;
float b1, z_123_x_45;
write("Enter a number");

/* 2: this is a 3-line
 comment
*/
n = read();
abc = n + -1e10f;
def = abc * abc;
def.abc();
write(def); /* 3: this is /* the end ***/
}
