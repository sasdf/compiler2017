int func(int a, int b)
{
	int main;
    a = 3;
	main = a * b;
}

int main()
{
	/* 1: this is just a sample */
    int c, d;
	float f,g;
	g = 3.3;
    c = 1;
    d = 3;
	/* 2: this is a 3-line
	comment
	*/
	f = read();
    func(c,e);
	write(d);
	d = 0;  /* 3: this is /* the end ***/
	
    return 0;
}
